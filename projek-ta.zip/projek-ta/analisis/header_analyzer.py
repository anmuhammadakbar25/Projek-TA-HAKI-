# header_analyzer.py

import re
from datetime import datetime
from curl_cffi import requests
from typing import Dict, Any, List

# =====================================================================
# CONFIGURATIONS
# =====================================================================

# Header weights (risk-based OWASP scoring - Total 100 Poin)
HEADER_WEIGHTS = {
    "Content-Security-Policy": 35, 
    "Strict-Transport-Security": 30,
    "X-Content-Type-Options": 15,
    "Cache-Control": 10,
    "X-Frame-Options": 5,
    "Permissions-Policy": 5,
}

MIN_SCORE = 0
MAX_SCORE = sum(HEADER_WEIGHTS.values()) # Total 100

# Grade boundaries (Tetap sama)
GRADES = [
    (100, "A+"), (90, "A"), (85, "A-"), (80, "B+"),
    (70, "B"), (65, "B-"), (60, "C+"), (50, "C"),
    (45, "C-"), (40, "D+"), (30, "D"), (25, "D-"),
    (0, "F"),
]

# =====================================================================
# HELPERS & REQUEST HANDLING
# =====================================================================

def grade_from_score(score: float) -> str:
    """Menentukan grade berdasarkan skor persentase."""
    for threshold, g in GRADES:
        if score >= threshold:
            return g
    return "F"

def fetch_headers(url):
    """Menggunakan curl_cffi untuk mendapatkan response headers."""
    try:
        r = requests.get(
            url,
            impersonate="chrome124",
            timeout=15,
            allow_redirects=True,
        )
        return r
    except Exception as e:
        print(f"[{datetime.now()}] ERROR fetching {url}: {e}")
        return None

# =====================================================================
# HEADER ANALYSIS FUNCTIONS
# =====================================================================

def analyze_csp(value):
    """Menganalisis Content-Security-Policy (Max 35 Poin) dengan logika berjenjang."""
    
    # Rekomendasi Best Practice OWASP
    BEST_PRACTICE_RECOMMENDATION = "Gunakan: `default-src 'self'; form-action 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; upgrade-insecure-requests`."
    
    # Kasus 1: CSP tidak ditemukan (0 Poin)
    if not value:
        return {
             "status": "FAIL", "score": 0,
             "reason": ["🚨 **Sangat Berbahaya:** CSP tidak ditemukan. Situs rentan terhadap XSS dan Clickjacking."],
             "recommendation": [BEST_PRACTICE_RECOMMENDATION],
             "raw": value or ""
         }
    
    # Normalisasi nilai untuk pemeriksaan case-insensitive
    normalized_value = value.lower()
    
    # Inisialisasi status dan skor
    score = 35
    problems = []
    
    # --- Pengecekan Kunci ---
    is_unsafe = "unsafe-inline" in normalized_value or "unsafe-eval" in normalized_value
    has_frame_ancestors = "frame-ancestors" in normalized_value
    
    # --- Skema Penilaian Berjenjang ---
    
    if is_unsafe:
        problems.append("❌ Mengandung `unsafe-inline` atau `unsafe-eval`. Ini membuka celah XSS yang serius.")
        # Pengurangan skor besar
        score -= 20
        
    if has_frame_ancestors:
        problems.append("⚠️ Mengandung `frame-ancestors` yang merupakan praktik modern anti-Clickjacking.")
        # Jika ada frame-ancestors, skor minimal 15 (Walaupun ada unsafe, tetap ada niat baik/basic protection)
        if score < 15:
             score = 15
        
    # Kasus 2: CSP Ada, tapi sangat basic dan tidak ada frame-ancestors
    if score == 35 and not has_frame_ancestors and not is_unsafe:
         problems.append("⚠️ Konfigurasi basic, tidak ditemukan `frame-ancestors 'none'` atau *directive* keamanan penting lainnya.")
         score = 15 # Diberi 15 poin untuk kehadiran dan tidak adanya unsafe.
    
    # Kasus 3: CSP Ada, Ada unsafe, dan tidak ada frame-ancestors
    if score == 15 and not has_frame_ancestors and is_unsafe:
        score = 5 # Skor sangat rendah karena unsafe, tapi > 0 karena ada header.
        
    # Kasus 4: CSP Ada, ada frame-ancestors, dan tidak ada unsafe (Skor Penuh)
    if score >= 35 and has_frame_ancestors and not is_unsafe:
        status = "PASS"
        score = 35 # Full Score
        reason = ["✅ CSP memiliki `frame-ancestors` dan bebas dari `unsafe` keyword. Konfigurasi sangat baik."]
    
    # Kasus Sisanya (FAIL/PARTIAL)
    else:
        status = "FAIL"
        reason = problems
        if not problems:
            reason = ["⚠️ CSP ditemukan, namun konfigurasinya basic. Tidak ditemukan *directive* keamanan penting seperti `frame-ancestors 'none'` atau `object-src 'none'` yang komprehensif."]
        
    # --- Hasil Akhir ---
    
    return {
        "status": status,
        "score": max(score, 5) if value else 0, # Pastikan skor minimal 5 jika header ada, kecuali jika kasusnya 0 (tidak ada header)
        "reason": reason,
        "recommendation": [
            *([f"Hapus keyword berbahaya: `unsafe-inline` atau `unsafe-eval`."] if is_unsafe else []),
            "Lengkapi CSP Anda sesuai best practice OWASP untuk membatasi semua resource penting:", 
            BEST_PRACTICE_RECOMMENDATION
        ],
        "raw": value,
    }


def analyze_hsts(value):
    """Menganalisis Strict-Transport-Security (Max 30 Poin)"""
    if not value:
        return {
            "status": "FAIL", "score": 0,
            "reason": ["🚨 HSTS tidak ditemukan. Situs rentan terhadap **Downgrade Attack** dari HTTP ke HTTPS."],
            "recommendation": ["Gunakan: `Strict-Transport-Security: max-age=31536000; includeSubDomains`."],
            "raw": value or ""
        }

    score = 30
    problems = []
    
    m = re.search(r"max-age=(\d+)", value, re.IGNORECASE)
    max_age = int(m.group(1)) if m else 0

    # Cek max-age (minimal 1 tahun: 31536000)
    if max_age < 31536000:
        problems.append(f"❌ `max-age` terlalu rendah ({max_age} detik). Minimal aman adalah 1 tahun (31536000 detik).")
        score -= 20

    # Cek includeSubDomains
    if "includesubdomains" not in value.lower():
        problems.append("⚠️ `includeSubDomains` tidak ditemukan. Subdomain Anda tidak terlindungi HSTS.")
        score -= 10

    if problems:
        return {
            "status": "PASS" if max(score, 0) > 0 else "FAIL",
            "score": max(score, 0),
            "reason": problems,
            "recommendation": ["Tingkatkan `max-age` menjadi minimal 31536000 dan tambahkan `includeSubDomains`."],
            "raw": value
        }

    return {
        "status": "PASS",
        "score": 30,
        "reason": ["✅ HSTS kuat, memaksa koneksi HTTPS."],
        "recommendation": ["Pertahankan header ini!"],
        "raw": value
    }

def analyze_xcto(value):
    """Menganalisis X-Content-Type-Options (Max 15 Poin)"""
    if value and value.lower() == "nosniff":
        return {
            "status": "PASS", "score": 15,
            "reason": ["✅ `nosniff` ditemukan. Mencegah browser salah menafsirkan tipe file (MIME Sniffing Attack)."],
            "recommendation": ["Pertahankan header ini!"],
            "raw": value,
        }

    return {
        "status": "FAIL", "score": 0,
        "reason": ["❌ X-Content-Type-Options tidak ditemukan atau bukan 'nosniff'."],
        "recommendation": ["Gunakan `X-Content-Type-Options: nosniff`"],
        "raw": value or "",
    }

def analyze_cache_control(value):
    """Menganalisis Cache-Control (Max 10 Poin)"""
    if not value:
        return {
            "status": "FAIL", "score": 0,
            "reason": ["❌ Cache-Control tidak ditemukan. Dapat menyebabkan browser/proxy menyimpan cache konten sensitif."],
            "recommendation": ["Untuk keamanan, gunakan `Cache-Control: no-store, max-age=0`."],
            "raw": value or "",
        }

    # Untuk keamanan tertinggi, kita cek apakah ada 'no-store' atau 'no-cache'.
    if "no-store" in value.lower() or "no-cache" in value.lower():
        return {
            "status": "PASS", "score": 10,
            "reason": ["✅ Cache-Control disetel dengan aman (`no-store` atau `no-cache`)."],
            "recommendation": ["Pertahankan header ini untuk menghindari cache yang tidak disengaja."],
            "raw": value,
        }

    return {
        "status": "FAIL", "score": 0,
        "reason": [f"❌ Nilai '{value}' dapat menyebabkan konten sensitif di-cache."],
        "recommendation": ["Gunakan `Cache-Control: no-store`"],
        "raw": value,
    }


def analyze_xfo(value):
    """Menganalisis X-Frame-Options (Max 5 Poin)"""
    if not value:
        return {
            "status": "FAIL", "score": 0,
            "reason": ["❌ X-Frame-Options tidak ditemukan. Rentan terhadap **Clickjacking**."],
            "recommendation": ["Gunakan: `X-Frame-Options: DENY` atau `SAMEORIGIN`. (Rekomendasi modern: gunakan `frame-ancestors 'none'` pada CSP)."],
            "raw": value or "",
        }

    if value.lower() in ["deny", "sameorigin"]:
        return {
            "status": "PASS", "score": 5,
            "reason": ["✅ X-Frame Option ditemukan (`DENY` atau `SAMEORIGIN`). Mencegah Clickjacking."],
            "recommendation": ["Bagus! Pertahankan header ini."],
            "raw": value,
        }

    return {
        "status": "FAIL", "score": 0,
        "reason": [f"❌ X-Frame-Options '{value}' tidak aman."],
        "recommendation": ["Gunakan X-Frame-Options: DENY"],
        "raw": value,
    }

def analyze_perm(value):
    """Menganalisis Permissions-Policy (Max 5 Poin)"""
    if not value:
        return {
            "status": "FAIL", "score": 0,
            "reason": ["❌ Permissions-Policy tidak ditemukan. Memungkinkan fitur browser sensitif (kamera, mikrofon, dll.) digunakan tanpa izin ketat."],
            "recommendation": ["Setel fitur sensitif yang tidak digunakan ke `()`."],
            "raw": value or "",
        }

    return {
        "status": "PASS", "score": 5,
        "reason": ["✅ Permissions-Policy ditemukan dan setidaknya mencoba membatasi fitur."],
        "recommendation": ["Bagus! Pertahankan dan periksa fitur lain yang tidak perlu."],
        "raw": value,
    }

# =====================================================================
# ANALYSIS DISPATCHER DAN WRAPPER
# =====================================================================

def analyze_headers(headers: Dict[str, str]) -> Dict[str, Any]:
    """Mengirim 6 header yang dipilih ke fungsi analisis yang sesuai."""
    return {
        "Content-Security-Policy": analyze_csp(headers.get("content-security-policy")),
        "Strict-Transport-Security": analyze_hsts(headers.get("strict-transport-security")),
        "X-Content-Type-Options": analyze_xcto(headers.get("x-content-type-options")),
        "Cache-Control": analyze_cache_control(headers.get("cache-control")),
        "X-Frame-Options": analyze_xfo(headers.get("x-frame-options")),
        "Permissions-Policy": analyze_perm(headers.get("permissions-policy")),
    }


def scan_url_and_analyze(url: str) -> Dict[str, Any]:
    """Menggabungkan fetching, analisis, dan scoring."""
    response = fetch_headers(url)

    if response is None:
        raise ConnectionError(f"Gagal mengambil header dari URL: {url}")
    
    if response.status_code >= 400:
        return {
            "scan_url": url,
            "http_status": response.status_code,
            "total_score": 0,
            "percentage": 0.00,
            "grade": "F",
            "security_headers": {},
        }

    raw_headers = {k.lower(): v for k, v in response.headers.items()}
    analysis_results = analyze_headers(raw_headers)
    
    total_score = sum(res['score'] for res in analysis_results.values())
    max_score = MAX_SCORE # Total 100
    percentage = (total_score / max_score) * 100
    grade = grade_from_score(percentage)

    return {
        "scan_url": url,
        "http_status": response.status_code,
        "total_score": total_score,
        "percentage": round(percentage, 2),
        "grade": grade,
        "security_headers": analysis_results,
    }