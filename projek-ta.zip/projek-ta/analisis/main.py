# main.py

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware # 💡 IMPORT BARU
from pydantic import BaseModel, Field
from typing import Dict, Any, List

# Mengimpor semua logika dan konfigurasi dari file header_analyzer
from header_analyzer import (
    fetch_headers, 
    analyze_headers, 
    grade_from_score, 
    MAX_SCORE
)

# =====================================================================
# FASTAPI DATA MODELS
# =====================================================================

# Model Data untuk setiap hasil Header
class HeaderResultAPI(BaseModel):
    status: str = Field(description="PASS/FAIL menunjukkan status header.")
    score: int = Field(description="Skor header individual (berdasarkan bobot).")
    reason: List[str] = Field(description="Daftar alasan skor diberikan.")
    recommendation: List[str] = Field(description="Daftar rekomendasi OWASP.")
    raw: str | None = Field(description="Nilai mentah dari header yang ditemukan.")

# Model Data untuk keseluruhan hasil Scan
class ScanResultAPI(BaseModel):
    scan_url: str = Field(description="URL yang berhasil diakses (setelah redirect).")
    http_status: int = Field(description="HTTP Status Code dari response.")
    total_score: float = Field(description="Total skor persentase (0-100).")
    grade: str = Field(description="Grade huruf berdasarkan total skor (A+, B, F, dll).")
    security_headers: Dict[str, HeaderResultAPI] = Field(description="Hasil analisis untuk setiap header.")

# =====================================================================
# FASTAPI APPLICATION SETUP
# =====================================================================

app = FastAPI(
    title="OWASP Header Compliance Scanner API",
    version="3.6",
    description="API untuk analisis kepatuhan security headers berdasarkan OWASP Best Practice."
)

# 💡 START: PENAMBAHAN CORS MIDDLEWARE
origins = [
    "http://localhost",    # Origin default XAMPP/Apache (Port 80)
    "http://127.0.0.1",    # Origin alternatif untuk XAMPP
    "http://localhost:8000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# 💡 END: PENAMBAHAN CORS MIDDLEWARE

# =====================================================================
# FASTAPI ENDPOINT
# =====================================================================

@app.get("/scan", response_model=ScanResultAPI)
async def api_scan_security_headers(url: str):
    """
    Endpoint API untuk memindai security headers pada URL tertentu.
    """

    # 1. Pastikan URL memiliki skema sebelum dikirim ke fetch_headers
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url

    # 2. Panggil fungsi Request dari header_analyzer.py
    r = fetch_headers(url)

    # 3. PENANGANAN ERROR (Jika request gagal)
    if not r:
        raise HTTPException(
            status_code=400,
            detail=f"Request gagal terhubung ke URL: {url}. Pastikan URL valid dan dapat diakses."
        )

    # 4. Konversi header keys ke huruf kecil untuk konsistensi analisis
    headers = {k.lower(): v for k, v in r.headers.items()}

    # 5. Panggil fungsi analisis logika
    analysis = analyze_headers(headers)

    # 6. Menghitung Total Skor dan Grade
    total_score = sum(v["score"] for v in analysis.values())
    
    # Hitung persentase total
    pct = total_score / MAX_SCORE * 100 
    
    # Tentukan Grade
    grade = grade_from_score(pct)

    # 7. Kembalikan hasil yang sesuai dengan model ScanResultAPI
    return ScanResultAPI(
        scan_url=r.url,
        http_status=r.status_code,
        total_score=float(f"{pct:.2f}"),
        grade=grade,
        security_headers=analysis
    )

if __name__ == "__main__":
    import uvicorn
    # Jalankan server untuk testing: uvicorn main:app --reload --port 8000
    uvicorn.run(app, host="0.0.0.0", port=8000)